เภสัช Dashboard – Supabase/Vercel package

ไฟล์ในชุดนี้:
- dashboard.html : dashboard หลัก
- drug_dashboard.html : หน้ารายการยา (ค้นหา/กรอง/แบ่งหน้า)
- api/data.js : Vercel serverless API อ่าน Supabase
- vercel.json : config Vercel
- data/*.json : fallback data สำหรับเมื่อ API ล้มเหลว

ตั้งค่า Vercel Environment Variables:
SUPABASE_URL = URL โปรเจกต์ Supabase
SUPABASE_SERVICE_ROLE_KEY = service_role key (ตั้งใน Vercel เท่านั้น ห้ามใส่ใน HTML)
หรือใช้ SUPABASE_ANON_KEY หากตั้ง RLS/permissions ให้อ่านได้อย่างเหมาะสม

Deploy โดยอัปโหลด/เชื่อม Git repository แล้ว deploy บน Vercel. เปิด dashboard.html เป็นหน้า Dashboard หลัก.
API: GET /api/data

ข้อจำกัด: ข้อมูล JSON fallback เป็นข้อมูลตัวอย่าง; API จริงต้องมี Supabase table app_config, drugs, stock, dispense_log ตาม schema.
