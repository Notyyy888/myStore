// Vercel Serverless Function: /api/data
// Required environment variables: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY
// Never expose the service-role key to client-side JavaScript.
const table = async (base, key, name, query = '') => {
  const url = `${base.replace(/\/$/, '')}/rest/v1/${name}?${query || 'select=*'}`;
  const response = await fetch(url, { headers: { apikey: key, Authorization: `Bearer ${key}`, Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Supabase ${name}: HTTP ${response.status}`);
  return response.json();
};
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const base = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!base || !key) return res.status(503).json({ error: 'Missing Supabase environment variables' });
  try {
    const [config, drugs, stock, dispense] = await Promise.all([
      table(base, key, 'app_config', 'select=as_of&id=eq.1'),
      table(base, key, 'drugs', 'select=*&order=sku.asc'),
      table(base, key, 'stock', 'select=*&order=sku.asc,lot.asc'),
      table(base, key, 'dispense_log', 'select=*&order=datetime.desc')
    ]);
    const asOf = config?.[0]?.as_of || new Date().toISOString().slice(0, 10);
    const meta = { as_of: asOf, source: 'supabase' };
    return res.status(200).json({
      drugs: { meta: { ...meta, count: drugs.length }, items: drugs },
      stock: { meta: { ...meta, count: stock.length }, items: stock },
      dispense_log: { meta: { ...meta, count: dispense.length }, items: dispense },
      catalog: { meta: { ...meta, count: drugs.length }, items: drugs }
    });
  } catch (error) {
    console.error('API data error:', error.message);
    return res.status(502).json({ error: 'Could not load Supabase datasets' });
  }
}
